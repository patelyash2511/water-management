<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        
        <!-- Title -->
        <title>Admin | Dashboard</title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <meta name="description" content="Responsive Admin Dashboard Template" />
        <meta name="keywords" content="admin,dashboard" />
        <meta name="author" content="Steelcoders" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.css" />
        <!-- Styles -->
        <link type="text/css" rel="stylesheet" href="../assets/plugins/materialize/css/materialize.min.css"/>
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">    
        <link href="../assets/plugins/metrojs/MetroJs.min.css" rel="stylesheet">
        <link href="../assets/plugins/weather-icons-master/css/weather-icons.min.css" rel="stylesheet">

        	
        <!-- Theme Styles -->
        <link href="../assets/css/alpha.min.css" rel="stylesheet" type="text/css"/>
        <link href="../assets/css/custom.css" rel="stylesheet" type="text/css"/>
        
    </head>
    <body>
           <?php include('includes/header.php');?>
            
       <?php include('includes/sidebar.php');?>


       <main class="mn-inner">
           
                <div class="row">
                    <div class="col s12">
                        <div class="page-title"><h4></h4></div>

                          <div class="col s12 m6 l8 offset-l2 offset-m3">
                              <div class="card white darken-1">
                             
                                  <div class="card-content ">
                                      <span class="card-title" style="font-size:20px;">Register</span>
                                         <?php if($msg){?><div class="errorWrap"><strong>Error</strong> : <?php echo htmlentities($msg); ?> </div><?php }?>
                                       <div class="row">
                                           <div  class="col s12"  >

                                           <label>
      <input class="with-gap" name="group3" type="radio" id="expert"  />
      <span>Expert</span>
    </label>
    <label>
      <input class="with-gap" name="group3" type="radio"  id="institute" />
      <span>Institute</span>
    </label>

    <form action="addExpert.php" class="col s12" name="signin" method="post">
    <div id="exp" style="display: none;">
                                               <div class="input-field col s12">
                                                   <input id="username" type="text" name="Ename" class="validate" autocomplete="off" required >
                                                     <label for="email">username</label>
                                               </div>
                                               <div class="input-field col s12">
                                                   <input id="password" type="email" class="validate" name="Eemail" autocomplete="off" required>
                                                   <label for="password">Email</label>
                                               </div>
                                               <div class="input-field col s12">
                                                   <input id="password" type="password" class="validate" name="Epass" autocomplete="off" required>
                                                   <label for="password">Password</label>
                                               </div>
                                               <div class="input-field col s12">
                                                   <input id="password" type="text" class="validate" name="Esub" autocomplete="off" required>
                                                   <label for="password">Subject</label>
                                               </div>
                                               <div class="input-field col s12">
                                                   <input id="password" type="text" class="validate" name="Eadd" autocomplete="off" required>
                                                   <label for="password">Address</label>
                                               </div>
                                               <div class="input-field col s12">
                                                   <input id="password" type="number" min="1111111111111" max="9999999999999" class="validate" name="Epno" autocomplete="off" required>
                                                   <label for="password">Ph No</label>
                                               </div>
                                               <div class="col s12 right-align m-t-sm">

                                                   <input type="submit" name="expert" value="Sign in" class="waves-effect waves-light btn teal">
                                               </div>
</div>
</form>
<form action="addInstitute.php" class="col s12"  method="post">
<div id="ins" style="display: none;">

<div class="input-field col s12">
                                                   <input id="username" type="text" name="Iname" class="validate" autocomplete="off" required >
                                                   <label for="email">Username</label>
                                               </div>
                                               <div class="input-field col s12">
                                                   <input id="username" type="password" name="Ipass" class="validate" autocomplete="off" required >
                                                   <label for="email">Password</label>
                                               </div>
                                               <div class="input-field col s12">
                                                   <input id="password" type="text" class="validate" name="Iiname" autocomplete="off" required>
                                                   <label for="password">Institute Name</label>
                                               </div>
                                               <div class="input-field col s12">
                                                   <input id="username" type="text" name="Iadd" class="validate" autocomplete="off" required >
                                                   <label for="email">Address</label>
                                               </div>
                                              
                                               <div class="col s12 right-align m-t-sm">

                                                   <input type="submit" name="institute" value="Sign in" class="waves-effect waves-light btn teal">
                                               </div>
</div>
</div>
</form>
</div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                    </div>
                </div>
            </main>



    
        <!-- Javascripts -->
        <script src="../assets/plugins/jquery/jquery-2.2.0.min.js"></script>
        <script src="../assets/plugins/materialize/js/materialize.min.js"></script>
        <script src="../assets/plugins/material-preloader/js/materialPreloader.min.js"></script>
        <script src="../assets/plugins/jquery-blockui/jquery.blockui.js"></script>
        <script src="../assets/plugins/waypoints/jquery.waypoints.min.js"></script>
        <script src="../assets/plugins/counter-up-master/jquery.counterup.min.js"></script>
        <script src="../assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
        <script src="../assets/plugins/chart.js/chart.min.js"></script>
        <script src="../assets/plugins/flot/jquery.flot.min.js"></script>
        <script src="../assets/plugins/flot/jquery.flot.time.min.js"></script>
        <script src="../assets/plugins/flot/jquery.flot.symbol.min.js"></script>
        <script src="../assets/plugins/flot/jquery.flot.resize.min.js"></script>
        <script src="../assets/plugins/flot/jquery.flot.tooltip.min.js"></script>
        <script src="../assets/plugins/curvedlines/curvedLines.js"></script>
        <script src="../assets/plugins/peity/jquery.peity.min.js"></script>
        <script src="../assets/js/alpha.min.js"></script>
        <script src="../assets/js/pages/dashboard.js"></script>
        <script>
        
        $('#institute').on('click',function(){
            $('#ins').show();
            $('#exp').hide();
        });
        $('#expert').on('click',function(){
            $('#exp').show();
            $('#ins').hide();
        });
        </script>
    </body>
</html>
<?php } ?>