     <aside id="slide-out" class="side-nav white fixed">
                <div class="side-nav-wrapper">
                    <div class="sidebar-profile">
                        <div class="sidebar-profile-image">
                            <img src="../assets/images/profile-image.png" class="circle" alt="">
                        </div>
                        <div class="sidebar-profile-info">
                       
                                <p>Society Secretory</p>

                         
                        </div>
                    </div>
            
                <ul class="sidebar-menu collapsible collapsible-accordion" data-collapsible="accordion">
                    <li class="no-padding"><a class="waves-effect waves-grey" href="/water/index.php"><i class="material-icons">settings_input_svideo</i>Website</a></li>
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">apps</i>Complain<i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>
                        <div class="collapsible-body">
                            <ul>
                              
                                <li><a href="complain.php">Make Complain</a></li>
                            </ul>
                        </div>
                    </li>
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">code</i>Order Tanker<i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>

                        <div class="collapsible-body">
                            <ul>
                              
                                <li><a href="tanker.php">Order Tanker</a></li>
                            </ul>
                        </div>
                    </li>
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">desktop_windows</i>Water Timing<i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>

                        <div class="collapsible-body">
                            <ul>
                              
                                <li><a href="watertiming.php">Water Timing</a></li>
                            </ul>
                        </div>

                    </li>

                        <li class="no-padding">
                                <a class="waves-effect waves-grey" href="/water/index.php"><i class="material-icons">exit_to_app</i>Sign Out</a>
                            </li>  
                 
              
                </ul>
                   <div class="footer">
                    <p class="copyright">Brought To You By SAVAJ Code-Projects </a>©</p>
                
                </div>
                </div>
            </aside>