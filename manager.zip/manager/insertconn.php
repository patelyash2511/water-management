<?php

$login=$_POST['login'];
$pass=$_POST['password'];
$sname=$_POST['sname'];
$saddress=$_POST['saddress'];
$ward=$_POST['ward'];
$phone=$_POST['phone'];


if( !empty($login) || !empty($pass) || !empty($sname) || !empty($saddress) || !empty($ward) || !empty($phone) || )
{
    $conn= new mysqli("localhost","root","","demop");

    $insert= "INSERT INTO `new_connection`(`login`, `pass`, `sname`, `saddress`, `ward`, `phone`) VALUES ('$login','$pass','$sname','$saddress','$ward','$phone')";
    $a=mysqli_query($conn,$insert);
    if(!$a)
    {
    	die("error".mysqli_error($conn));
    }
    else
    {
    	header('location:index.php');
    }
}
else
{
    echo "all fields are required";
    die();
}
?>