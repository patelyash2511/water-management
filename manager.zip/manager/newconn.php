<?php

$login=$_POST['login'];
$pass=$_POST['password'];
$sname=$_POST['sname'];
$saddress=$_POST['saddress'];
$ward=$_POST['ward'];
$phone=$_POST['phone'];


if( !empty($login) || !empty($pass) || !empty($sname) || !empty($saddress) || !empty($ward) || !empty($phone) || )
{
    $conn= new mysqli("localhost","root","","demop");

    $insert= "INSERT INTO `new_connection`(`login`, `pass`, `sname`, `saddress`, `ward`, `phone`) VALUES ('$login','$pass','$sname','$saddress','$ward','$phone')";
    $a=mysqli_query($conn,$insert);
    if(!$a)
    {
        die("error".mysqli_error($conn));
    }
    else
    {
        header('location:index.php');
    }
}
else
{
    echo "all fields are required";
    die();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>New Connection Form</title>

    <link href="css/main1.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading">
                    <h2 class="title">New Water Connection</h2>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-row m-b-55">
                            <div class="name">Email ID & Password</div>
                            <div class="value">
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="email" name="email" required>
                                            <label class="label--desc">Email id</label>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="password" name="password" required>
                                            <label class="label--desc">Password</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Society name</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="socname" required>
                                
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="name">Society address</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="saddress" required>
                                
                                </div>
                            </div>
                        </div>

                         <div class="form-row">
                            <div class="name">Adharcard Number</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="Number" min="111111111111" max="999999999999" name="anumber" required>
                                
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Ward Number</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="Number" min="11" max="99" name="ward" required>
                                </div>
                            </div>
                        </div>
                        
                        
                        <div class="form-row m-b-55">
                            <div class="name">Phone</div>
                            <div class="value">
                                <div class="row row-refine">
                                    <div class="col-9">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="Number" min="1111111111" max="9999999999" name="Phone" required>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                
                        <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <!--<button class="btn btn--radius-2 btn--red" type="submit">Register</button>
                              &nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;-->   
                              <input type="submit" value="Register" class="btn btn--radius-2 btn--red" name="login">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</html>
